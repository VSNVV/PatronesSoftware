package Adapter;

public class AdaptadorDinero {
    // Atributos de la clase AdaptadorDinero
    private int euro;

    // Métodos de la clase AdaptadorDinero
    public AdaptadorDinero(Euro euro)
}
