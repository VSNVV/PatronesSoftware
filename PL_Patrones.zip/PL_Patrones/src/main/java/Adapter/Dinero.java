package Adapter;

public interface Dinero {
    int valor();
}
