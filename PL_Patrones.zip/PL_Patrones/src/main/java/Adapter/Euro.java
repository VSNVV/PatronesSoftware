package Adapter;

public class Euro {
    // Atributos de la clase Euro
    private double valor;

    // Métodos de la clase Euro
    public Euro(double valor){
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }
}
