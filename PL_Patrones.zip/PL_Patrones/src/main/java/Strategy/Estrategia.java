package Strategy;

public interface Estrategia {
    // Métodos de la interfaz Estrategia
    double calcular(double precio);
}
