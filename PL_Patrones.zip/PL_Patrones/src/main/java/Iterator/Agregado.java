package Iterator;

public interface Agregado {
    // Métodos de la interfaz Agregado

    // Método para crear un Iterador
    Iterador crearIterador();
}
