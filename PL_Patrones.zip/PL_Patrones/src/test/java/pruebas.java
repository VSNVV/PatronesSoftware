import concurrencia.Vehiculo;

import java.util.ArrayList;
import java.util.Random;

public class pruebas{
    public static void main(String[] args){
        int opcion = (int)(Math.random() * 2 + 1);
        System.out.println(opcion);

    }
}
